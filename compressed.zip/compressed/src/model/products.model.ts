
export interface ProductsModel {
    title:string,
    price:number,
    popularity:number,
    subcategory:string
  }
  